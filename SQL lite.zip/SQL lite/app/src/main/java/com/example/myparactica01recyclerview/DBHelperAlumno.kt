package com.example.myparactica01recyclerview

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelperAlumno(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "Alumnos.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_NAME = "Alumnos"
        const val COLUMN_ID = "id"
        const val COLUMN_NOMBRE = "nombre"
        const val COLUMN_CUENTA = "cuenta"
        const val COLUMN_CORREO = "correo"
        const val COLUMN_IMAGEN = "imagen"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$COLUMN_NOMBRE TEXT, "
                + "$COLUMN_CUENTA TEXT, "
                + "$COLUMN_CORREO TEXT, "
                + "$COLUMN_IMAGEN TEXT)")
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertAlumno(alumno: Alumno): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NOMBRE, alumno.nombre)
            put(COLUMN_CUENTA, alumno.cuenta)
            put(COLUMN_CORREO, alumno.correo)
            put(COLUMN_IMAGEN, alumno.imagen)
        }
        val result = db.insert(TABLE_NAME, null, values)
        db.close()
        return result
    }

    fun getAllAlumnos(): ArrayList<Alumno> {
        val listAlumnos = ArrayList<Alumno>()
        val selectQuery = "SELECT * FROM $TABLE_NAME"
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery(selectQuery, null)

        cursor.use {
            if (it.moveToFirst()) {
                val idIndex = it.getColumnIndexOrThrow(COLUMN_ID)
                val nombreIndex = it.getColumnIndexOrThrow(COLUMN_NOMBRE)
                val cuentaIndex = it.getColumnIndexOrThrow(COLUMN_CUENTA)
                val correoIndex = it.getColumnIndexOrThrow(COLUMN_CORREO)
                val imagenIndex = it.getColumnIndexOrThrow(COLUMN_IMAGEN)

                do {
                    val id = it.getInt(idIndex)
                    val nombre = it.getString(nombreIndex)
                    val cuenta = it.getString(cuentaIndex)
                    val correo = it.getString(correoIndex)
                    val imagen = it.getString(imagenIndex)

                    val alumno = Alumno(id, nombre, cuenta, correo, imagen)
                    listAlumnos.add(alumno)
                } while (it.moveToNext())
            }
        }
        db.close()
        return listAlumnos
    }

    fun updateAlumno(alumno: Alumno): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NOMBRE, alumno.nombre)
            put(COLUMN_CUENTA, alumno.cuenta)
            put(COLUMN_CORREO, alumno.correo)
            put(COLUMN_IMAGEN, alumno.imagen)
        }
        val success = db.update(TABLE_NAME, values, "$COLUMN_ID=?", arrayOf(alumno.id.toString()))
        db.close()
        return success
    }

    fun deleteAlumno(id: Int): Int {
        val db = writableDatabase
        val success = db.delete(TABLE_NAME, "$COLUMN_ID=?", arrayOf(id.toString()))
        db.close()
        return success
    }
}
