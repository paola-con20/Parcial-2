package com.example.myparactica01recyclerview

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myparactica01recyclerview.databinding.ActivityMainBinding
import com.example.myparactica01recyclerview.databinding.DialogAlumnoBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DBHelperAlumno
    private lateinit var alumnoAdapter: AlumnoAdapter
    private var listaAlumnos = ArrayList<Alumno>()

    private var currentDialogBinding: DialogAlumnoBinding? = null

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            try {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            currentDialogBinding?.etImagen?.setText(it.toString())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setSupportActionBar(binding.toolbar)

        dbHelper = DBHelperAlumno(this)

        setupRecyclerView()
        cargarAlumnos()

        binding.fabAgregar.setOnClickListener {
            mostrarDialogoAgregar()
        }
    }

    private fun setupRecyclerView() {
        alumnoAdapter = AlumnoAdapter(
            listAlumnos = listaAlumnos,
            onEditClick = { alumno -> mostrarDialogoEditar(alumno) },
            onDeleteClick = { alumno -> confirmarEliminacion(alumno) }
        )

        binding.contentMain.rvAlumnos.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = alumnoAdapter
        }
    }

    private fun cargarAlumnos() {
        listaAlumnos = dbHelper.getAllAlumnos()

        if (listaAlumnos.isEmpty()) {
            insertarDatosPrueba()
            listaAlumnos = dbHelper.getAllAlumnos()
        }

        alumnoAdapter.updateList(listaAlumnos)
        actualizarEstadoLista()
    }

    private fun insertarDatosPrueba() {
        val alumno1 = Alumno(
            nombre = "María García",
            cuenta = "20231001",
            correo = "maria.garcia@email.com",
            imagen = "https://picsum.photos/id/1027/200/200"
        )
        val alumno2 = Alumno(
            nombre = "Carlos López",
            cuenta = "20231002",
            correo = "carlos.lopez@email.com",
            imagen = "https://picsum.photos/id/1005/200/200"
        )
        val alumno3 = Alumno(
            nombre = "Ana Martínez",
            cuenta = "20231003",
            correo = "ana.martinez@email.com",
            imagen = "https://picsum.photos/id/1011/200/200"
        )

        dbHelper.insertAlumno(alumno1)
        dbHelper.insertAlumno(alumno2)
        dbHelper.insertAlumno(alumno3)
    }

    private fun actualizarEstadoLista() {
        if (listaAlumnos.isEmpty()) {
            binding.contentMain.tvEmpty.visibility = View.VISIBLE
            binding.contentMain.rvAlumnos.visibility = View.GONE
        } else {
            binding.contentMain.tvEmpty.visibility = View.GONE
            binding.contentMain.rvAlumnos.visibility = View.VISIBLE
        }
    }

    private fun mostrarDialogoAgregar() {
        val dialogBinding = DialogAlumnoBinding.inflate(LayoutInflater.from(this))
        currentDialogBinding = dialogBinding
        dialogBinding.tvTituloDialogo.setText(R.string.agregar_alumno)

        dialogBinding.btnSeleccionarGaleria.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.btn_guardar) { dialog, _ ->
                val nombre = dialogBinding.etNombre.text.toString().trim()
                val cuenta = dialogBinding.etCuenta.text.toString().trim()
                val correo = dialogBinding.etCorreo.text.toString().trim()
                val imagen = dialogBinding.etImagen.text.toString().trim()

                if (nombre.isNotEmpty() && cuenta.isNotEmpty()) {
                    val nuevoAlumno = Alumno(
                        nombre = nombre,
                        cuenta = cuenta,
                        correo = correo,
                        imagen = imagen
                    )
                    val result = dbHelper.insertAlumno(nuevoAlumno)
                    if (result > -1) {
                        Toast.makeText(this, R.string.msg_guardado_ok, Toast.LENGTH_SHORT).show()
                        cargarAlumnos()
                    } else {
                        Toast.makeText(this, R.string.msg_error_guardar, Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                } else {
                    Toast.makeText(this, R.string.msg_campos_obligatorios, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.btn_cancelar) { dialog, _ ->
                dialog.dismiss()
            }
            .setOnDismissListener {
                currentDialogBinding = null
            }
            .create()
            .show()
    }

    private fun mostrarDialogoEditar(alumno: Alumno) {
        val dialogBinding = DialogAlumnoBinding.inflate(LayoutInflater.from(this))
        currentDialogBinding = dialogBinding
        dialogBinding.tvTituloDialogo.setText(R.string.editar_alumno)

        dialogBinding.etNombre.setText(alumno.nombre)
        dialogBinding.etCuenta.setText(alumno.cuenta)
        dialogBinding.etCorreo.setText(alumno.correo)
        dialogBinding.etImagen.setText(alumno.imagen)

        dialogBinding.btnSeleccionarGaleria.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.btn_actualizar) { dialog, _ ->
                val nombre = dialogBinding.etNombre.text.toString().trim()
                val cuenta = dialogBinding.etCuenta.text.toString().trim()
                val correo = dialogBinding.etCorreo.text.toString().trim()
                val imagen = dialogBinding.etImagen.text.toString().trim()

                if (nombre.isNotEmpty() && cuenta.isNotEmpty()) {
                    val alumnoActualizado = Alumno(
                        id = alumno.id,
                        nombre = nombre,
                        cuenta = cuenta,
                        correo = correo,
                        imagen = imagen
                    )
                    val rowsAffected = dbHelper.updateAlumno(alumnoActualizado)
                    if (rowsAffected > 0) {
                        Toast.makeText(this, R.string.msg_actualizado_ok, Toast.LENGTH_SHORT).show()
                        cargarAlumnos()
                    } else {
                        Toast.makeText(this, R.string.msg_error_actualizar, Toast.LENGTH_SHORT).show()
                    }
                    dialog.dismiss()
                } else {
                    Toast.makeText(this, R.string.msg_campos_obligatorios, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.btn_cancelar) { dialog, _ ->
                dialog.dismiss()
            }
            .setOnDismissListener {
                currentDialogBinding = null
            }
            .create()
            .show()
    }

    private fun confirmarEliminacion(alumno: Alumno) {
        val mensaje = getString(R.string.confirmar_eliminar_msg, alumno.nombre)

        AlertDialog.Builder(this)
            .setTitle(R.string.eliminar_alumno)
            .setMessage(mensaje)
            .setPositiveButton(R.string.btn_eliminar) { dialog, _ ->
                val rowsDeleted = dbHelper.deleteAlumno(alumno.id)
                if (rowsDeleted > 0) {
                    Toast.makeText(this, R.string.msg_eliminado_ok, Toast.LENGTH_SHORT).show()
                    cargarAlumnos()
                } else {
                    Toast.makeText(this, R.string.msg_error_eliminar, Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton(R.string.btn_cancelar) { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }
}
