package com.example.myparactica01recyclerview

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import com.example.myparactica01recyclerview.databinding.ItemPersonaBinding

class AlumnoAdapter(
    private var listAlumnos: ArrayList<Alumno>,
    private val onEditClick: (Alumno) -> Unit,
    private val onDeleteClick: (Alumno) -> Unit
) : RecyclerView.Adapter<AlumnoAdapter.AlumnoViewHolder>() {

    class AlumnoViewHolder(val binding: ItemPersonaBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumnoViewHolder {
        val binding = ItemPersonaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AlumnoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AlumnoViewHolder, position: Int) {
        val alumno = listAlumnos[position]
        with(holder.binding) {
            tvNombre.text = alumno.nombre
            tvCuenta.text = root.context.getString(R.string.cuenta_formato, alumno.cuenta)
            tvCorreo.text = alumno.correo

            val urlOPath = alumno.imagen.trim()

            if (urlOPath.isNotBlank()) {
                val modelToLoad: Any = when {
                    urlOPath.startsWith("http://") || urlOPath.startsWith("https://") -> {
                        GlideUrl(
                            urlOPath,
                            LazyHeaders.Builder()
                                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                                .build()
                        )
                    }
                    urlOPath.startsWith("content://") || urlOPath.startsWith("file://") -> {
                        Uri.parse(urlOPath)
                    }
                    else -> urlOPath
                }

                Glide.with(root.context)
                    .load(modelToLoad)
                    .centerCrop()
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_dialog_alert)
                    .into(imgFoto)
            } else {
                imgFoto.setImageResource(android.R.drawable.ic_menu_gallery)
            }

            btnEditar.setOnClickListener {
                onEditClick(alumno)
            }

            btnEliminar.setOnClickListener {
                onDeleteClick(alumno)
            }
        }
    }

    override fun getItemCount(): Int = listAlumnos.size

    fun updateList(newList: ArrayList<Alumno>) {
        this.listAlumnos = newList
        notifyDataSetChanged()
    }
}
