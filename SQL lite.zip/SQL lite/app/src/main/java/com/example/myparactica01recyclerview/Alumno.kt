package com.example.myparactica01recyclerview

data class Alumno(
    val id: Int = 0,
    var nombre: String,
    var cuenta: String,
    var correo: String,
    var imagen: String
)
